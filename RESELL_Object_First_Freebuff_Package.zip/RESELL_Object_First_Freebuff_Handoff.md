# RESELL — Object First / Safe Freebuff Handoff

**Status:** Standalone interactive HTML prototype created and JavaScript syntax-checked. **NOT integrated with the live Freebuff project, GitHub, Convex, authentication, inventory, or publishing.**

## What exists

- `RESELL_Object_First_Prototype.html`: a complete standalone responsive prototype, including embedded transparent illustrative camera art, a hero, three narrative scenes (found / admin burden / record), CSS state transitions with IntersectionObserver, reduced-motion styling, an explanatory Capture–Understand–Decide–Sell flow, and a local-only photo preview.
- `resell_camera_cutout.webp`: the illustrative cutout asset separately, for replacement with licensed, genuine product photography in production.

The prototype's photo picker only previews a local file in the browser. **It does not save, recognise, value, list, or upload an object.**

## Source isolation warning

The local Windows repository `C:\Users\max\resell-chief` tracks `https://github.com/UNIFORM1TY/resell-chief.git`, but its most recently observed checkout commit is **7a67526 from 4 October 2026** and it contains substantial uncommitted changes. The remote `main` observed on Windows was also from October 4. The current Freebuff workspace agent reports additional newer implementation, and no verified one-to-one source/deployment mapping is established.

**Do not copy or overwrite the old local Git checkout, reset it, or assume pushing to it updates the Freebuff live deployment.**

## Integration instructions for Freebuff agent (after mapping is verified)

1. Read current cloud source and identify the actual current hero, Section 01 (the administrative department) and route mapping.
2. Snapshot or create a safe isolated branch/preservation point, including all subsequent legitimate changes.
3. Reuse styling, narrative structure, and motion rules from `RESELL_Object_First_Prototype.html`. Do not replace the entire app with this standalone file.
4. Replace the illustrative camera with an authorised, genuinely high-quality object cutout image. Preserve the original evidence photo separately. Keep no fake condition, price or sale statistics.
5. Wire primary CTA into the existing authenticated Capture operation. Keep real create/save/error confirmation from the backend and human approval as designed. Remove the local-only demo picker after connecting the real workflow.
6. Keep Today, Source, Stock, Sell, Orders, all active selling plans, manual marketplace states, integration boundary and other projects untouched.
7. Browser-test 320, 390, 768, 1024, 1440 widths, 200% browser zoom, reduced motion, keyboard tab order, object clipping, scroll transition states, network console and Core Web Vitals.
8. Stage a comparison preview, report changed files and tests, and seek explicit review before publishing.

## Known limitations / verification

- **Verified:** HTML file exists; JavaScript parses; object asset is transparent WebP and self-contained; no external JavaScript dependency; illustrative/local-only status labels present.
- **Not verified:** Visual screenshot review. Local headless browser returned `net::ERR_BLOCKED_BY_ADMINISTRATOR` when opening the sandbox HTML file, so no browser-based layout or interaction claims are made.
- **Not attempted:** Live Freebuff edit, external marketplace action, deploy, automatic publishing, real database changes or Git push.

## Design goals

- Industrial and editorial, not sci-fi or glassmorphism.
- One tactile object, one idea per section, big clear language, subtle motion.
- Three-scene narrative: find → ridiculous admin → usable record.
- Preserve meaningful state and browser accessibility, rather than animations for their own sake.
